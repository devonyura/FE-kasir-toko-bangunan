import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircleIcon } from "lucide-react";
import { axiosInstance } from "@/utils/axios";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: (msg: string) => void;
}

type DetailBarang = {
  barang_id: number;
  satuan_id: number;
  nama_barang: string;
  nama_satuan: string;
};

export default function ReturDialogForm({
  open,
  onOpenChange,
  onSuccess,
}: Props) {
  const [tanggal, setTanggal] = useState("");
  const [jenis, setJenis] = useState("penjualan");
  const [noNota, setNoNota] = useState("");
  const [transaksiId, setTransaksiId] = useState(""); // hidden data
  const [barangSatuanOptions, setBarangSatuanOptions] = useState<
    DetailBarang[]
  >([]);
  const [selectedBarangSatuan, setSelectedBarangSatuan] = useState<string>("");

  const [qty, setQty] = useState("");
  const [alasan, setAlasan] = useState("");

  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      const today = new Date().toISOString().slice(0, 10);
      setTanggal(today);
      setJenis("penjualan");
      setNoNota("");
      setTransaksiId("");
      setBarangSatuanOptions([]);
      setSelectedBarangSatuan("");
      setQty("");
      setAlasan("");
      setError("");
    }
  }, [open]);

  const handleCariTransaksi = async () => {
    try {
      const endpoint =
        jenis === "penjualan"
          ? `/transaksi-jual/${noNota}`
          : `/transaksi-beli/${noNota}`;

      const res = await axiosInstance.get(endpoint);
      const data = res.data.data;

      setTransaksiId(data.transaksi.id);
      setBarangSatuanOptions(data.detail || []);
    } catch (err: undefined) {
      setError(`Transaksi tidak ditemukan. Periksa nomor nota: ${err}`);
      setBarangSatuanOptions([]);
    }
  };

  const handleSubmit = async () => {
    try {
      const [barang_id, satuan_id] = selectedBarangSatuan
        .split("-")
        .map((val) => parseInt(val));

      const payload = {
        tanggal,
        jenis,
        transaksi_id: transaksiId,
        no_nota: noNota,
        barang_id,
        satuan_id,
        qty: Number(qty),
        alasan,
      };

      await axiosInstance.post("/retur", payload);
      onSuccess("Retur berhasil disimpan.");
      onOpenChange(false);
    } catch (err) {
      console.log(err);
      const msg = err?.response?.data?.message || "Gagal menyimpan retur.";
      setError(msg);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]" aria-describedby="">
        <DialogHeader>
          <DialogTitle>Tambah Retur Barang</DialogTitle>
        </DialogHeader>

        {error && (
          <Alert variant="destructive">
            <AlertCircleIcon className="h-5 w-5" />
            <AlertTitle>Gagal</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid gap-4">
          <div>
            <Label>Tanggal</Label>
            <Input
              type="date"
              value={tanggal}
              onChange={(e) => setTanggal(e.target.value)}
            />
          </div>

          <div>
            <Label>Jenis Retur</Label>
            <Select value={jenis} onValueChange={(val) => setJenis(val)}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih jenis retur" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="penjualan">Penjualan</SelectItem>
                <SelectItem value="pembelian">Pembelian</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>No Nota</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Contoh: 40"
                value={noNota}
                onChange={(e) => setNoNota(e.target.value)}
              />
              <Button type="button" onClick={handleCariTransaksi}>
                Cari
              </Button>
            </div>
          </div>

          <div>
            <Label>Pilih Barang</Label>
            <Select
              value={selectedBarangSatuan}
              onValueChange={setSelectedBarangSatuan}
            >
              <SelectTrigger>
                <SelectValue placeholder="Pilih barang" />
              </SelectTrigger>
              <SelectContent>
                {barangSatuanOptions.map((item) => (
                  <SelectItem
                    key={`${item.barang_id}-${item.satuan_id}`}
                    value={`${item.barang_id}-${item.satuan_id}`}
                  >
                    {item.nama_barang} ({item.nama_satuan})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Qty</Label>
            <Input
              type="number"
              value={qty}
              onChange={(e) => setQty(e.target.value)}
            />
          </div>

          <div>
            <Label>Alasan Retur</Label>
            <Input
              placeholder="Contoh: Barang rusak, expired..."
              value={alasan}
              onChange={(e) => setAlasan(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter className="mt-4">
          <DialogClose asChild>
            <Button variant="outline">Batal</Button>
          </DialogClose>
          <Button onClick={handleSubmit}>Simpan</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
