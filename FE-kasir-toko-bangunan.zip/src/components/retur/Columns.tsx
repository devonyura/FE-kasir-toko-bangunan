import type { ColumnDef } from "@tanstack/react-table";

export const columns: ColumnDef<unknown>[] = [
  {
    accessorKey: "tanggal",
    header: "Tanggal",
  },
  {
    accessorKey: "jenis",
    header: "Jenis",
  },
  {
    accessorKey: "nama_barang",
    header: "Barang",
  },
  {
    accessorKey: "nama_satuan",
    header: "Satuan",
  },
  {
    accessorKey: "qty",
    header: "Qty",
  },
  {
    accessorKey: "alasan",
    header: "Alasan Retur",
  },
];
