export type Barang = {
  id: string;
  nama_barang: string;
  kategori_id: string;
  kode_barang: string;
  keterangan: string;
  nama_kategori?: string;
};
