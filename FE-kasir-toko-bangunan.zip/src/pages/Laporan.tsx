export default function Laporan() {
  return <div className="text-xl font-medium">Halaman Laporan</div>;
}