export default function Transaksi() {
  return <div className="text-xl font-medium">Halaman Transaksi</div>;
}
